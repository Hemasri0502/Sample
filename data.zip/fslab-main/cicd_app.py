 def add(a, b):
       """Adds two numbers."""
       return a + b

   def subtract(a, b):
       """Subtracts two numbers."""
       return a - b
   
